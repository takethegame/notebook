using UnrealBuildTool;

public class CesiumForUnrealSamples : ModuleRules
{
	public CesiumForUnrealSamples(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PrivateDependencyModuleNames.Add("Core");
		PrivateDependencyModuleNames.Add("Core");
	}
}
