using UnrealBuildTool;

public class CesiumForUnrealSamplesClientTarget : TargetRules
{
	public CesiumForUnrealSamplesClientTarget(TargetInfo Target) : base(Target)
	{
		DefaultBuildSettings = BuildSettingsVersion.V3;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		Type = TargetType.Client;
		ExtraModuleNames.Add("CesiumForUnrealSamples");
	}
}
