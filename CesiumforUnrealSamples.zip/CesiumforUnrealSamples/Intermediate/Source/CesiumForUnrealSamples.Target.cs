using UnrealBuildTool;

public class CesiumForUnrealSamplesTarget : TargetRules
{
	public CesiumForUnrealSamplesTarget(TargetInfo Target) : base(Target)
	{
		DefaultBuildSettings = BuildSettingsVersion.V3;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		Type = TargetType.Game;
		ExtraModuleNames.Add("CesiumForUnrealSamples");
	}
}
