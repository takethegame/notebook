using UnrealBuildTool;

public class CesiumForUnrealSamplesServerTarget : TargetRules
{
	public CesiumForUnrealSamplesServerTarget(TargetInfo Target) : base(Target)
	{
		DefaultBuildSettings = BuildSettingsVersion.V3;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		Type = TargetType.Server;
		ExtraModuleNames.Add("CesiumForUnrealSamples");
	}
}
