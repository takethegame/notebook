using UnrealBuildTool;

public class CesiumForUnrealSamplesEditorTarget : TargetRules
{
	public CesiumForUnrealSamplesEditorTarget(TargetInfo Target) : base(Target)
	{
		DefaultBuildSettings = BuildSettingsVersion.V3;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		Type = TargetType.Editor;
		ExtraModuleNames.Add("CesiumForUnrealSamples");
	}
}
